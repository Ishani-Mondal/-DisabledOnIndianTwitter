Please use the 'Ishani' sheetname in Set2.xlsx
Use 'Main' Sheet in Set3.xlsx
Use Sheet1 and Sheet2 in Set5.xlsx
Use 'Main' Sheet in Set6.xlsx
